<!DOCTYPE html>
<html>
<head>
    <title>Stats Dashboard</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Welcome to the Stats Dashboard</h1>
    <p>This is the main entry point.</p>
</body>
</html>