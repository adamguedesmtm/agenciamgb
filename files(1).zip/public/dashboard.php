<?php
// Display admin dashboard with stats and recent demos

// Fetch dashboard data from SQLite database
// Implement dashboard data fetching logic here

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Admin Dashboard</h1>
    <!-- Display dashboard stats and recent demos here -->
</body>
</html>