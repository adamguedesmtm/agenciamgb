#!/bin/bash
# Outros scripts de configuração

echo "Executando outros scripts de configuração..."

# Adicionar qualquer outra configuração necessária aqui