#!/bin/bash
# Script para instalar e configurar o CS Demo Manager

sudo apt update
sudo apt install -y cs-demo-manager

# Configurar CS Demo Manager
echo "Configurando CS Demo Manager..."
# Adicione a configuração necessária aqui