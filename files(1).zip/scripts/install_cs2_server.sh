#!/bin/bash
# Script para instalar e configurar o servidor de CS2

sudo apt update
sudo apt install -y cs2-server

# Configurar servidor
echo "Configurando servidor de CS2..."
# Adicione a configuração necessária aqui