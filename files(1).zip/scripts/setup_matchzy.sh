#!/bin/bash
# Script para clonar e copiar arquivos do MatchZy

git clone https://github.com/MatchZy/MatchZy.git
cp -r MatchZy/* /var/www/stats/