#!/bin/bash
# Script para iniciar o servidor de CS2

./start_cs2_server -c /path/to/config